<?php
include "elements/db_connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="login-form">
        <h2>ADMIN LOGIN PANEL</h2>
        <form  method="POST">
            <div class="input-field">
                <i class="fas fa-user"></i>
                <input type="text" placeholder="Admin Name" name="name">
            </div>
            <div class="input-field">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Password" name="password">
            </div>

            <button type="submit" name="signin">Sign in</button>
        </form>
    </div>

    <?php
    if(isset($_POST['signin'])){
        $query = "SELECT * FROM `admin` WHERE `name`='$_POST[name]' AND `password`='$_POST[password]'";
        $result = mysqli_query($conn,$query);
        if(mysqli_num_rows($result)==1)
        {
            session_start();
            $_SESSION['admin_login_id']=$_POST['name'];
            header("location:admin1/index.php");
        }
        else {
            echo "<script>alert('Incorrect Password');</script>";
        }
    }
    
    ?>
</body>
</html>